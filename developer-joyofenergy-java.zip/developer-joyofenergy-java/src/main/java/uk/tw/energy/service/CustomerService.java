package uk.tw.energy.service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import org.springframework.stereotype.Service;
import uk.tw.energy.domain.Customer;
import uk.tw.energy.domain.ElectricityReading;

@Service
public class CustomerService {

    // Simulating customer data storage
    private final List<Customer> customers = new ArrayList<>();

    // Simulating price plan rules
    private final List<String> pricePlans = List.of("price-plan-0", "price-plan-1", "price-plan-2");

    public CustomerService() {
        // Adding some dummy data
        customers.add(new Customer("customer-0", "Sarah", "smart-meter-0", "price-plan-0"));
        customers.add(new Customer("customer-1", "Peter", "smart-meter-1", "price-plan-1"));
        customers.add(new Customer("customer-2", "Charlie", "smart-meter-2", "price-plan-0"));
        customers.add(new Customer("customer-3", "Andrea", "smart-meter-3", "price-plan-2"));
        customers.add(new Customer("customer-4", "Alex", "smart-meter-4", "price-plan-1"));
    }

    // Method to get a customer by their customer ID
    public Optional<Customer> getCustomerById(String customerId) {
        return customers.stream()
                .filter(customer -> customer.customerId().equals(customerId))
                .findFirst();
    }

    // Method to get all customers
    public List<Customer> getAllCustomers() {
        return new ArrayList<>(customers);
    }

    // Simulate electricity readings for a smart meter
    public List<ElectricityReading> getReadingsBySmartMeter(String smartMeterId) {
        List<ElectricityReading> readings = new ArrayList<>();
        Instant now = Instant.now();
        Random random = new Random();

        // Generate random readings for the past 1 hour, 1 reading per minute
        for (int i = 0; i < 60; i++) {
            Instant timestamp = now.minusSeconds(i * 60); // 1 reading every minute
            BigDecimal readingValue =
                    BigDecimal.valueOf(random.nextDouble() * 10).setScale(4, BigDecimal.ROUND_HALF_UP);
            readings.add(new ElectricityReading(timestamp, readingValue));
        }

        return readings;
    }

    // Method to get the price plan of a specific customer
    public Optional<String> getPricePlanByCustomerId(String customerId) {
        return getCustomerById(customerId).map(Customer::pricePlanId);
    }

    // Calculate the most suitable price plan for a customer
    public Optional<String> getSuitablePricePlan(String customerId) {
        Optional<Customer> customerOptional = getCustomerById(customerId);
        if (customerOptional.isEmpty()) {
            return Optional.empty();
        }

        Customer customer = customerOptional.get();
        String smartMeterId = customer.smartMeterId();

        // Simulated readings for the customer's smart meter
        List<ElectricityReading> readings = getReadingsBySmartMeter(smartMeterId);

        // Calculate total usage in kW manually without using getReading()
        var ref = new Object() {
            BigDecimal totalUsage = BigDecimal.ZERO;
        };
        for (ElectricityReading reading : readings) {
            // Access the reading directly through the record fields
            ref.totalUsage = ref.totalUsage.add(reading.reading());
        }

        // Determine the most suitable price plan (simple logic for demonstration)
        String suitablePlan = pricePlans.stream()
                .min((plan1, plan2) -> {
                    BigDecimal cost1 = calculateCost(plan1, ref.totalUsage);
                    BigDecimal cost2 = calculateCost(plan2, ref.totalUsage);
                    return cost1.compareTo(cost2);
                })
                .orElse("unknown");

        return Optional.of(suitablePlan);
    }

    // Simulated cost calculation for each price plan
    private BigDecimal calculateCost(String pricePlan, BigDecimal totalUsage) {
        // Simplistic cost per KW for each price plan
        switch (pricePlan) {
            case "price-plan-0":
                return totalUsage.multiply(BigDecimal.valueOf(0.10)); // 10 cents per KW
            case "price-plan-1":
                return totalUsage.multiply(BigDecimal.valueOf(0.12)); // 12 cents per KW
            case "price-plan-2":
                return totalUsage.multiply(BigDecimal.valueOf(0.15)); // 15 cents per KW
            default:
                return BigDecimal.valueOf(Double.MAX_VALUE); // Invalid plan
        }
    }
}
