package uk.tw.energy.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uk.tw.energy.domain.Customer;
import uk.tw.energy.domain.ElectricityReading;
import uk.tw.energy.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private final CustomerService customerService;

    // Constructor injection
    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    // 1. Get customer details by customer ID
    @GetMapping("/{customerId}")
    public ResponseEntity<Customer> getCustomer(@PathVariable String customerId) {
        Optional<Customer> customer = customerService.getCustomerById(customerId);
        return customer.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 2. Get all customers
    @GetMapping()
    public ResponseEntity<List<Customer>> getAllCustomers() {
        List<Customer> customers = customerService.getAllCustomers();
        return ResponseEntity.ok(customers);
    }

    // 3. Get all meter readings for a specific customer
    @GetMapping("/{customerId}/readings")
    public ResponseEntity<List<ElectricityReading>> getMeterReadingsForCustomer(@PathVariable String customerId) {
        Optional<Customer> customer = customerService.getCustomerById(customerId);
        if (customer.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<ElectricityReading> readings =
                customerService.getReadingsBySmartMeter(customer.get().smartMeterId());
        return ResponseEntity.ok(readings);
    }

    // 4. Get price plan for a specific customer
    @GetMapping("/{customerId}/price-plan")
    public ResponseEntity<String> getCustomerPricePlan(@PathVariable String customerId) {
        Optional<String> pricePlan = customerService.getPricePlanByCustomerId(customerId);
        return pricePlan.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound()
                .build());
    }

    // 5. Get the most suitable price plan for a customer
    @GetMapping("/{customerId}/suitable-price-plan")
    public ResponseEntity<String> getSuitablePricePlan(@PathVariable String customerId) {
        Optional<String> suitablePlan = customerService.getSuitablePricePlan(customerId);
        return suitablePlan.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound()
                .build());
    }
}
