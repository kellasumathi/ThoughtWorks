package uk.tw.energy.domain;

public record Customer(String customerId, String name, String smartMeterId, String pricePlanId) {}
